package bisonToLpg;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.Collection;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Properties;
import java.util.SortedSet;
import java.util.TreeSet;

import bisonToLpg.ast.Alternative;
import bisonToLpg.ast.Grammar;
import bisonToLpg.ast.Rule;
import bisonToLpg.ast.Symbol;

public final class TerminalsWriter {
   
   public static void printLpgTerminals(PrintStream out, Grammar g) {
      Collection<String> nonTerminals = new LinkedList<String>();
      SortedSet<String> possibleTerminals = new TreeSet<String>();
      for (Rule r: g.rules) {
         nonTerminals.add(r.left.name);
         for (Alternative alt: r.right.alternatives) {
            for (Symbol s: alt.rhsSymbols) {
               possibleTerminals.add(s.name);
            }
         }
      }
      possibleTerminals.removeAll(nonTerminals);
      Map<Character,String> namesForChars = getNamesForChars();
      out.println("%Terminals");
      for (String terminal: possibleTerminals) {
         out.print(LPGRuleGenerator.INDENT);
         if ( terminal.startsWith("\"") || terminal.startsWith("'") ) {
            String identifier = g.declarationInfo.get("token."+terminal);
            if ( identifier==null ) {
               identifier = synthesizedIdentifierFor(terminal, namesForChars);
            }
            out.print(identifier);
            out.print( " ::= " );
         }
         out.println(terminal);
      }
      out.println("%End");
   }
   
   private static final Map<Character,String> getNamesForChars() {
      Map<Character,String> result = new HashMap<Character,String>();
      try {
         InputStream is = new FileInputStream("SpecialCharNames.properties");
         Properties p = new Properties();
         p.load(is);
         for (Map.Entry<Object, Object> e: p.entrySet() ) {
            String propertyKey = (String) e.getKey();
            String propertyValue = (String) e.getValue();
            char c;
            if ( propertyValue.length()==0 ) {
               c = ' ';
            } else {
               c = propertyValue.charAt(0);
            }
            result.put(c, propertyKey);
         }
      } catch (IOException e) {
         for (char c=0; c<128; c++) {
            result.put(c, "CHAR"+c);
         }
      }
      return result;
   }
   
   private static final String synthesizedIdentifierFor(String stringConst, Map<Character,String> namesForChars) {
      char[] stringConstChars = stringConst.toCharArray();
      StringBuilder result = new StringBuilder();
      boolean inIdentifierMode = true;
      boolean inEscapeMode = false;
      int closingQuoteIndex = stringConstChars.length-1;
      for (int i=1; i<closingQuoteIndex; i++) {
         char c = stringConstChars[i];
         if ( c=='\\' && !inEscapeMode ) {
            inEscapeMode = true;
         } else {
            inEscapeMode = false;
            if ( Character.isLetter(c) ) {
               if ( !inIdentifierMode ) {
                  result.append('_');
                  inIdentifierMode = true;
               }
               result.append( Character.toUpperCase(c) );
            } else if ( Character.isDigit(c) ) {
               if ( i==1 || !inIdentifierMode ) {
                  result.append('_');
               }
               result.append(c);
            } else if ( c=='-' && inIdentifierMode && i != 1 ) {
               result.append('_');
            } else {
               if ( i!=1 ) {
                  result.append('_');
               }
               result.append(namesForChars.get(c));
               inIdentifierMode = false;
            }
         }
      }
      return result.toString();
   }
   

}