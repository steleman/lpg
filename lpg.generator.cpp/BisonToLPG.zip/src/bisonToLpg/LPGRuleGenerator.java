package bisonToLpg;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;

import bisonToLpg.ast.Alternative;
import bisonToLpg.ast.Grammar;
import bisonToLpg.ast.Rule;
import bisonToLpg.ast.Symbol;
import bisonToLpg.parserForBisonGrammars.BisonLexer;
import bisonToLpg.parserForBisonGrammars.BisonParser;

public class LPGRuleGenerator {
   
   public static final String INDENT = "   ";
   
   @SuppressWarnings("serial")
   private static final class FatalException extends Exception {
      public FatalException(String message) { super(message); }
   }

   public static void main(String[] args) {
      try {
         String prologFileName;
         String bisonFileName;
         String epilogFileName;
         String outputFileName;
         if ( args.length == 4 ) {
            prologFileName = args[0];
            bisonFileName = args[1];
            epilogFileName = args[2];
            outputFileName = args[3];
         } else {
            throw new FatalException("Syntax is: java " + LPGRuleGenerator.class.getName() + " lpg-prolog-file-name bison-file-name lpg-epilog-file-name lpg-output-file-name" );
         }
         PrintStream out;
         try {
            out = new PrintStream(outputFileName);
         } catch (FileNotFoundException e) {
            throw new FatalException("Error opening \"" + outputFileName + "\" for writing. Terminating." );
         }

         printFile(prologFileName, "prolog", out);
         Grammar g = parseBisonFile(bisonFileName);
         if ( g==null ) {
            System.err.println("Terminating because of syntax errors in Bison file.");
            return;
         }
         out.println();
         TerminalsWriter.printLpgTerminals(out, g);
         out.println();
         printStartSymbol(out, g);
         out.println();
         printLpgRules(out, g);
         out.println();
         printFile(epilogFileName, "epilog", out);
         out.close();
         System.err.println("Done.");
      } catch (FatalException e) {
         System.err.println( e.getMessage() );
      }

   }

   private static Grammar parseBisonFile(String bisonFileName) throws FatalException {
      BisonLexer lexer;
      try {
         lexer = new BisonLexer(bisonFileName, 1);
      } catch (IOException e) {
         throw new FatalException("Error reading \"" + bisonFileName + "\". Terminating." );
      }
      BisonParser parser = new BisonParser( lexer.getLexStream() );
      lexer.lexer( parser.getParseStream() );
      return (Grammar) parser.parser();
   }
   
   private static void printStartSymbol(PrintStream out, Grammar g) throws FatalException {
      String startSymbol = g.declarationInfo .get("startSymbol");
      if ( startSymbol==null ) {
         if ( g.rules.isEmpty() ) {
            throw new FatalException("Bison grammar is empty.");
         } else {
            startSymbol = g.rules.get(0).left.name; // Start symbol defaults to lhs of first production
         }
      }
      out.println("%Start");
      out.print(INDENT);
      out.println(startSymbol);
      out.println("%End");
   }

   private static void printLpgRules(PrintStream out, Grammar g) {
      out.println("%Rules");
      for (Rule r: g.rules) {
         out.println();
         String lhs = r.left.name;
         out.print(INDENT);
         out.print(lhs);
         out.print(" ::=");
         int additionalSpaces = lhs.length() + 3;
         StringBuilder continuationIndentBuilder = new StringBuilder(INDENT);
         for (int i=0; i < additionalSpaces; i++) {
            continuationIndentBuilder.append(' ');
         }
         continuationIndentBuilder.append('|');
         String continuationIndent = continuationIndentBuilder.toString();
         boolean vbarNeeded = false;
         for (Alternative alt: r.right.alternatives) {
            if ( vbarNeeded ) {
               out.print(continuationIndent);
            } else {
               vbarNeeded = true;
            }
            if ( alt.rhsSymbols.isEmpty() ) {
               out.println(" %empty");
            } else {
               for (Symbol s: alt.rhsSymbols) {
                  out.print(' ');
                  out.print(s.name);
               }
               out.println();
            }
         }
      }
      out.println("\n%End");
   }
   
   private static void printFile(String sourceFileName, String sourceFileDesc, PrintStream target) throws FatalException {
      BufferedReader in;
      try {
         in = new BufferedReader( new FileReader(sourceFileName) );
      } catch (FileNotFoundException e) {
         throw new FatalException
            ("The " + sourceFileDesc + " file \"" + sourceFileName +
                  "\" was not found. Terminating.");
      }
      try {
         String line = in.readLine();
         while ( line != null ) {
            target.println(line);
            line = in.readLine();
         }
         in.close();
      } catch (IOException e) {
         throw new FatalException
            ( "Terminating due to error reading " + sourceFileDesc + " file \"" + 
                  sourceFileName + "\": " + e.getMessage() );
      }
   }

}
