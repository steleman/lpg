package bisonToLpg.parserForBisonGrammars;

import lpg.runtime.*;
import org.eclipse.imp.parser.IParser;
import java.util.*;
import bisonToLpg.ast.*;

public class BisonParser implements RuleAction, IParser
{
    private PrsStream prsStream = null;
    
    private boolean unimplementedSymbolsWarning = false;

    private static ParseTable prsTable = new BisonParserprs();
    public ParseTable getParseTable() { return prsTable; }

    private DeterministicParser dtParser = null;
    public DeterministicParser getParser() { return dtParser; }

    private void setResult(Object object) { dtParser.setSym1(object); }
    public Object getRhsSym(int i) { return dtParser.getSym(i); }

    public int getRhsTokenIndex(int i) { return dtParser.getToken(i); }
    public IToken getRhsIToken(int i) { return prsStream.getIToken(getRhsTokenIndex(i)); }
    
    public int getRhsFirstTokenIndex(int i) { return dtParser.getFirstToken(i); }
    public IToken getRhsFirstIToken(int i) { return prsStream.getIToken(getRhsFirstTokenIndex(i)); }

    public int getRhsLastTokenIndex(int i) { return dtParser.getLastToken(i); }
    public IToken getRhsLastIToken(int i) { return prsStream.getIToken(getRhsLastTokenIndex(i)); }

    public int getLeftSpan() { return dtParser.getFirstToken(); }
    public IToken getLeftIToken()  { return prsStream.getIToken(getLeftSpan()); }

    public int getRightSpan() { return dtParser.getLastToken(); }
    public IToken getRightIToken() { return prsStream.getIToken(getRightSpan()); }

    public int getRhsErrorTokenIndex(int i)
    {
        int index = dtParser.getToken(i);
        IToken err = prsStream.getIToken(index);
        return (err instanceof ErrorToken ? index : 0);
    }
    public ErrorToken getRhsErrorIToken(int i)
    {
        int index = dtParser.getToken(i);
        IToken err = prsStream.getIToken(index);
        return (ErrorToken) (err instanceof ErrorToken ? err : null);
    }

    public void reset(ILexStream lexStream)
    {
        prsStream = new PrsStream(lexStream);
        dtParser.reset(prsStream);

        try
        {
            prsStream.remapTerminalSymbols(orderedTerminalSymbols(), BisonParserprs.EOFT_SYMBOL);
        }
        catch(NullExportedSymbolsException e) {
        }
        catch(NullTerminalSymbolsException e) {
        }
        catch(UnimplementedTerminalsException e)
        {
            if (unimplementedSymbolsWarning) {
                java.util.ArrayList unimplemented_symbols = e.getSymbols();
                System.out.println("The Lexer will not scan the following token(s):");
                for (int i = 0; i < unimplemented_symbols.size(); i++)
                {
                    Integer id = (Integer) unimplemented_symbols.get(i);
                    System.out.println("    " + BisonParsersym.orderedTerminalSymbols[id.intValue()]);               
                }
                System.out.println();
            }
        }
        catch(UndefinedEofSymbolException e)
        {
            throw new Error(new UndefinedEofSymbolException
                                ("The Lexer does not implement the Eof symbol " +
                                 BisonParsersym.orderedTerminalSymbols[BisonParserprs.EOFT_SYMBOL]));
        }
    }
    
    public BisonParser()
    {
        try
        {
            dtParser = new DeterministicParser(prsStream, prsTable, (RuleAction) this);
        }
        catch (NotDeterministicParseTableException e)
        {
            throw new Error(new NotDeterministicParseTableException
                                ("Regenerate BisonParserprs.java with -NOBACKTRACK option"));
        }
        catch (BadParseSymFileException e)
        {
            throw new Error(new BadParseSymFileException("Bad Parser Symbol File -- BisonParsersym.java. Regenerate BisonParserprs.java"));
        }
    }

    public BisonParser(ILexStream lexStream)
    {
        this();
        reset(lexStream);
    }

    public int numTokenKinds() { return BisonParsersym.numTokenKinds; }
    public String[] orderedTerminalSymbols() { return BisonParsersym.orderedTerminalSymbols; }
    public String getTokenKindName(int kind) { return BisonParsersym.orderedTerminalSymbols[kind]; }            
    public int getEOFTokenKind() { return BisonParserprs.EOFT_SYMBOL; }
    public PrsStream getParseStream() { return prsStream; }

    public ASTNode parser()
    {
        return parser(null, 0);
    }
        
    public ASTNode parser(Monitor monitor)
    {
        return parser(monitor, 0);
    }
        
    public ASTNode parser(int error_repair_count)
    {
        return parser(null, error_repair_count);
    }
        
    public ASTNode parser(Monitor monitor, int error_repair_count)
    {
        dtParser.setMonitor(monitor);

        try
        {
            return (ASTNode) dtParser.parse();
        }
        catch (BadParseException e)
        {
            prsStream.reset(e.error_token); // point to error token

            DiagnoseParser diagnoseParser = new DiagnoseParser(prsStream, prsTable);
            diagnoseParser.diagnose(e.error_token);
        }

        return null;
    }

    //
    // Additional entry points, if any
    //
    

    public void ruleAction(int ruleNumber)
    {
        switch (ruleNumber)
        {
 
            //
            // Rule 1:  input ::= declarations %% grammar epilogue_opt
            //
            case 1: {
     Map<String,String> declarationInfo = (Map<String,String>) getRhsSym(1);
     Grammar g = (Grammar) getRhsSym(3);
     g.declarationInfo = declarationInfo;
     setResult(g);
                 break;
            } 
            //
            // Rule 2:  declarations ::= $Empty
            //
            case 2: {
     setResult( new HashMap<String,String>() );
                 break;
            } 
            //
            // Rule 3:  declarations ::= declarations declaration
            //
            case 3: {
     Map<String,String> oldInfo = (Map<String,String>) getRhsSym(1);
     Map<String,String> newInfo = (Map<String,String>) getRhsSym(2);
     oldInfo.putAll(newInfo);
     setResult(oldInfo);
                 break;
            } 
            //
            // Rule 4:  declaration ::= grammar_declaration
            //
            case 4: {
     setResult(getRhsSym(1)); 
                 break;
            } 
            //
            // Rule 5:  declaration ::= other_declaration
            //
            case 5: {
     setResult( new HashMap<String,String>() );
                 break;
            } 
            //
            // Rule 32:  grammar_declaration ::= %start symbol
            //
            case 32: {
     Symbol startSymbol = (Symbol) getRhsSym(2);
     Map<String,String> startSymbolMap = new TreeMap<String,String>();
     startSymbolMap.put("startSymbol", startSymbol.name);
     setResult(startSymbolMap);
                 break;
            } 
            //
            // Rule 33:  grammar_declaration ::= %token symbol_defs_1
            //
            case 33: {
     setResult(getRhsSym(2)); 
                 break;
            } 
            //
            // Rule 34:  grammar_declaration ::= other_grammar_declaration
            //
            case 34: {
     setResult( new TreeMap<String,String>() );
                 break;
            } 
            //
            // Rule 51:  symbol_def ::= type
            //
            case 51: {
     setResult( new TreeMap<String,String>() );
                 break;
            } 
            //
            // Rule 52:  symbol_def ::= ID
            //
            case 52: {
     setResult( new TreeMap<String,String>() );
                 break;
            } 
            //
            // Rule 53:  symbol_def ::= ID INT
            //
            case 53: {
     setResult( new TreeMap<String,String>() );
                 break;
            } 
            //
            // Rule 54:  symbol_def ::= ID string_as_id
            //
            case 54: {
     String identifier = getRhsIToken(1).toString();
     Symbol stringConstant = (Symbol) getRhsSym(2);
     Map<String,String> info = new TreeMap<String,String>();
     info.put("token." + stringConstant.name, identifier);
     setResult(info);
                 break;
            } 
            //
            // Rule 55:  symbol_def ::= ID INT string_as_id
            //
            case 55: {
     String identifier = getRhsIToken(1).toString();
     Symbol stringConstant = (Symbol) getRhsSym(3);
     Map<String,String> info = new TreeMap<String,String>();
     info.put("token." + stringConstant.name, identifier);
     setResult(info);
                 break;
            } 
            //
            // Rule 56:  symbol_defs_1 ::= symbol_def
            //
            case 56: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 57:  symbol_defs_1 ::= symbol_defs_1 symbol_def
            //
            case 57: {
     Map<String,String> oldInfo = (Map<String,String>) getRhsSym(1);
     Map<String,String> newInfo = (Map<String,String>) getRhsSym(2);
     oldInfo.putAll(newInfo);
     setResult(oldInfo);
                 break;
            } 
            //
            // Rule 58:  grammar ::= rules
            //
            case 58: {
     setResult( new Grammar((Rule)getRhsSym(1)) );
                 break;
            } 
            //
            // Rule 59:  grammar ::= grammar_declaration
            //
            case 59: {
     setResult( new Grammar() );
                 break;
            } 
            //
            // Rule 60:  grammar ::= grammar rules
            //
            case 60: {
     Grammar prevGrammar = (Grammar) getRhsSym(1);
     Rule r = (Rule) getRhsSym(2); 
     prevGrammar.rules.add(r);
     setResult(prevGrammar);
                 break;
            } 
            //
            // Rule 61:  grammar ::= grammar grammar_declaration
            //
            case 61: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 62:  rules ::= ID COLON rhses_1
            //
            case 62: {
     Symbol lhs = new Symbol( getRhsIToken(1).toString() );
     Rhs rhs = (Rhs) getRhsSym(3);
     setResult( new Rule(lhs, rhs) );
                 break;
            } 
            //
            // Rule 63:  rhses_1 ::= rhs
            //
            case 63: {
     Rhs newRhs = new Rhs((Alternative)getRhsSym(1));
     setResult(newRhs);
                 break;
            } 
            //
            // Rule 64:  rhses_1 ::= rhses_1 | rhs
            //
            case 64: {
     Rhs prevRhs = (Rhs) getRhsSym(1);
     Alternative alt = (Alternative) getRhsSym(3); 
     prevRhs.alternatives.add(alt);
     setResult(prevRhs);
                 break;
            } 
            //
            // Rule 65:  rhses_1 ::= rhses_1 ;
            //
            case 65: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 66:  rhs ::= $Empty
            //
            case 66: {
     setResult( new Alternative() );
                 break;
            } 
            //
            // Rule 67:  rhs ::= rhs symbol
            //
            case 67: {
     Alternative prevAlt = (Alternative) getRhsSym(1);
     Symbol sym = (Symbol) getRhsSym(2);
     if ( sym.name != "%empty" ) { 
        prevAlt.rhsSymbols.add(sym);
     }
     setResult(prevAlt);
                 break;
            } 
            //
            // Rule 68:  rhs ::= rhs action
            //
            case 68: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 69:  rhs ::= rhs %prec symbol
            //
            case 69: {
     Alternative prevAlt = (Alternative) getRhsSym(1);
     Symbol sym = (Symbol) getRhsSym(3); 
     prevAlt.rhsSymbols.add(sym);
     setResult(prevAlt);
                 break;
            } 
            //
            // Rule 70:  rhs ::= rhs %dprec INT
            //
            case 70: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 71:  rhs ::= rhs %merge type
            //
            case 71: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 73:  symbol ::= ID
            //
            case 73: {
     setResult( new Symbol(getRhsIToken(1).toString()) );
                 break;
            } 
            //
            // Rule 74:  symbol ::= string_as_id
            //
            case 74: {
     setResult(getRhsSym(1));
                 break;
            } 
            //
            // Rule 128:  string_as_id ::= STRING
            //
            case 128: {
     setResult( new Symbol( getRhsIToken(1).toString() ) );
                 break;
            }
    
            default:
                break;
        }
        return;
    }
}

