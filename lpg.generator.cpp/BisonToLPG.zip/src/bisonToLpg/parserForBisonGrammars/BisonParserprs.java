package bisonToLpg.parserForBisonGrammars;

public class BisonParserprs implements lpg.runtime.ParseTable, BisonParsersym {
    public final static int ERROR_SYMBOL = 54;
    public final int getErrorSymbol() { return ERROR_SYMBOL; }

    public final static int SCOPE_UBOUND = 0;
    public final int getScopeUbound() { return SCOPE_UBOUND; }

    public final static int SCOPE_SIZE = 1;
    public final int getScopeSize() { return SCOPE_SIZE; }

    public final static int MAX_NAME_LENGTH = 24;
    public final int getMaxNameLength() { return MAX_NAME_LENGTH; }

    public final static int NUM_STATES = 57;
    public final int getNumStates() { return NUM_STATES; }

    public final static int NT_OFFSET = 54;
    public final int getNtOffset() { return NT_OFFSET; }

    public final static int LA_STATE_OFFSET = 439;
    public final int getLaStateOffset() { return LA_STATE_OFFSET; }

    public final static int MAX_LA = 2;
    public final int getMaxLa() { return MAX_LA; }

    public final static int NUM_RULES = 135;
    public final int getNumRules() { return NUM_RULES; }

    public final static int NUM_NONTERMINALS = 28;
    public final int getNumNonterminals() { return NUM_NONTERMINALS; }

    public final static int NUM_SYMBOLS = 82;
    public final int getNumSymbols() { return NUM_SYMBOLS; }

    public final static int SEGMENT_SIZE = 8192;
    public final int getSegmentSize() { return SEGMENT_SIZE; }

    public final static int START_STATE = 148;
    public final int getStartState() { return START_STATE; }

    public final static int IDENTIFIER_SYMBOL = 0;
    public final int getIdentifier_SYMBOL() { return IDENTIFIER_SYMBOL; }

    public final static int EOFT_SYMBOL = 41;
    public final int getEoftSymbol() { return EOFT_SYMBOL; }

    public final static int EOLT_SYMBOL = 41;
    public final int getEoltSymbol() { return EOLT_SYMBOL; }

    public final static int ACCEPT_ACTION = 303;
    public final int getAcceptAction() { return ACCEPT_ACTION; }

    public final static int ERROR_ACTION = 304;
    public final int getErrorAction() { return ERROR_ACTION; }

    public final static boolean BACKTRACK = false;
    public final boolean getBacktrack() { return BACKTRACK; }

    public final int getStartSymbol() { return lhs(0); }
    public final boolean isValidForParser() { return BisonParsersym.isValidForParser; }


    public interface IsNullable {
        public final static byte isNullable[] = {0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,1,0,0,1,
            0,0,1,0,1,0,0,0,1,1,
            1,0
        };
    };
    public final static byte isNullable[] = IsNullable.isNullable;
    public final boolean isNullable(int index) { return isNullable[index] != 0; }

    public interface ProsthesesIndex {
        public final static byte prosthesesIndex[] = {0,
            22,13,11,10,17,18,21,7,15,16,
            19,27,12,14,23,25,26,2,3,4,
            5,6,8,9,20,24,28,1
        };
    };
    public final static byte prosthesesIndex[] = ProsthesesIndex.prosthesesIndex;
    public final int prosthesesIndex(int index) { return prosthesesIndex[index]; }

    public interface IsKeyword {
        public final static byte isKeyword[] = {0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0
        };
    };
    public final static byte isKeyword[] = IsKeyword.isKeyword;
    public final boolean isKeyword(int index) { return isKeyword[index] != 0; }

    public interface BaseCheck {
        public final static byte baseCheck[] = {0,
            4,0,2,1,1,1,1,2,3,1,
            1,2,2,3,1,2,2,1,3,1,
            1,3,2,1,2,2,1,1,1,1,
            3,2,2,1,1,2,3,2,3,3,
            1,1,3,1,1,1,0,1,1,2,
            1,1,2,2,3,1,2,1,1,2,
            2,3,1,3,2,0,2,2,3,3,
            3,3,1,1,1,3,2,2,0,1,
            1,1,1,1,1,1,1,1,1,1,
            1,1,1,1,1,1,1,1,1,1,
            1,1,1,1,1,1,1,1,1,1,
            1,1,1,1,1,1,1,1,1,1,
            1,1,1,1,1,1,1,1,1,0,
            2,0,2,2,2,-3,-33,0,0,-5,
            -4,-28,0,0,0,0,0,-1,0,0,
            0,0,0,-25,0,0,-2,0,0,0,
            0,0,0,0,0,0,0,-9,0,-52,
            0,0,0,-53,0,-57,0,0,0,-42,
            -21,-27,-10,-23,0,0,0,0,0,0,
            0,-22,0,0,0,0,0,0,-34,0,
            0,-35,0,0,0,0,-13,0,-39,0,
            0,-24,0,0,0,-37,0,-14,-40,-15,
            0,-43,0,0,0,0,-44,0,0,-45,
            0,0,-26,0,-46,0,0,-49,0,0,
            -56,0,0,-6,-7,-36,-8,0,0,0,
            -11,-12,-16,0,0,-17,0,-18,0,-19,
            0,-20,0,-29,-30,-31,0,0,0,0,
            -32,-38,0,-41,0,-48,0,-50,-54,-47,
            -51,-55,0,0,0,0,0,0,0,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0
        };
    };
    public final static byte baseCheck[] = BaseCheck.baseCheck;
    public final int baseCheck(int index) { return baseCheck[index]; }
    public final static byte rhs[] = baseCheck;
    public final int rhs(int index) { return rhs[index]; };

    public interface BaseAction {
        public final static char baseAction[] = {
            18,18,19,19,22,22,23,23,23,23,
            23,23,23,23,23,23,23,23,23,23,
            23,23,23,23,23,23,23,23,23,23,
            23,24,8,8,8,9,9,9,9,9,
            9,9,9,10,11,11,11,25,25,6,
            6,7,7,7,7,7,14,14,20,20,
            20,20,15,26,26,26,16,16,16,16,
            16,16,5,2,2,17,3,13,13,13,
            12,12,12,12,12,12,12,12,12,12,
            12,12,12,12,12,12,12,12,12,12,
            12,12,12,12,12,12,12,12,12,12,
            12,12,12,12,12,12,12,12,12,12,
            12,12,12,12,12,12,12,12,1,4,
            21,21,27,27,27,27,440,203,74,49,
            53,567,53,227,4,34,35,192,42,59,
            34,35,192,182,550,222,58,253,3,5,
            6,154,61,34,35,192,157,136,341,60,
            479,74,67,75,149,1,540,74,67,75,
            149,526,1,347,526,78,51,68,56,51,
            176,56,594,68,77,216,170,48,219,203,
            74,49,203,74,49,230,281,435,235,203,
            74,49,203,74,32,238,586,209,485,591,
            569,51,55,57,51,78,57,250,74,50,
            297,74,50,47,77,344,74,50,391,74,
            50,203,74,69,436,436,483,300,26,25,
            23,300,300,436,17,16,300,271,300,137,
            300,199,593,38,436,436,436,202,22,19,
            14,439,588,54,101,9,534,55,108,593,
            595,589,596,304,71,304,304,304,304,304,
            133,304,304,304,304,304,304,304,304,304,
            304,278,304,304
        };
    };
    public final static char baseAction[] = BaseAction.baseAction;
    public final int baseAction(int index) { return baseAction[index]; }
    public final static char lhs[] = baseAction;
    public final int lhs(int index) { return lhs[index]; };

    public interface TermCheck {
        public final static byte termCheck[] = {0,
            0,1,2,3,4,5,6,7,8,9,
            10,11,12,13,14,15,16,17,18,19,
            20,21,22,23,24,25,26,27,28,29,
            30,31,32,33,34,35,36,37,38,39,
            40,0,42,43,44,45,0,47,48,49,
            50,51,0,53,0,1,2,3,4,5,
            6,7,8,9,10,11,12,13,14,15,
            16,17,18,19,20,21,22,23,24,25,
            26,27,28,29,30,31,32,33,34,35,
            36,37,38,39,40,49,42,43,44,45,
            0,47,48,49,50,51,52,0,1,2,
            3,4,5,6,7,8,9,10,11,12,
            13,14,15,16,17,18,19,20,21,22,
            23,24,25,26,27,28,29,30,31,32,
            33,34,35,36,37,38,39,40,0,42,
            43,44,45,0,47,48,49,50,51,52,
            0,1,2,3,4,5,6,7,8,9,
            10,11,12,13,14,15,16,17,18,19,
            20,21,22,23,24,25,26,27,28,29,
            30,31,32,33,34,35,36,37,38,39,
            40,41,0,1,2,0,46,0,1,2,
            3,4,5,6,7,8,9,10,11,12,
            13,14,15,16,17,18,19,20,21,22,
            23,24,25,26,27,28,29,30,31,32,
            33,34,35,36,37,38,39,40,41,0,
            1,2,0,46,0,1,2,3,4,5,
            6,7,8,9,10,11,12,13,14,15,
            16,17,18,19,20,21,22,23,24,25,
            26,27,28,29,30,31,32,33,34,35,
            36,37,38,41,0,41,0,1,2,0,
            46,0,1,2,3,4,5,6,7,8,
            9,10,11,12,13,14,15,16,17,18,
            19,20,21,22,23,24,25,26,27,28,
            29,30,31,32,33,34,35,36,37,38,
            0,42,41,0,1,2,0,46,0,1,
            2,3,4,5,6,7,8,9,10,11,
            12,13,14,15,16,17,18,19,20,21,
            22,23,24,25,26,27,28,29,30,31,
            32,33,34,35,36,37,38,47,0,41,
            0,1,2,47,46,0,1,2,3,4,
            5,6,7,8,9,10,11,12,13,14,
            15,16,17,18,19,20,21,22,23,24,
            25,26,27,28,29,30,31,32,33,34,
            35,36,37,38,0,0,41,2,0,0,
            2,46,3,4,5,6,7,8,9,10,
            11,12,13,14,15,16,17,18,19,20,
            21,22,23,24,25,26,27,28,29,30,
            31,32,33,34,35,36,37,38,0,1,
            2,47,0,1,0,46,0,1,2,3,
            4,5,6,7,8,9,10,11,12,13,
            14,15,16,0,1,2,3,4,5,6,
            7,8,9,10,11,12,13,14,15,16,
            42,43,44,45,40,0,1,41,42,43,
            44,45,0,0,48,2,0,0,0,0,
            1,2,0,0,41,42,43,44,45,0,
            1,48,3,4,5,6,7,8,9,10,
            11,12,13,14,39,16,0,1,0,3,
            4,5,6,7,8,9,10,11,12,13,
            14,42,43,44,45,0,1,0,0,2,
            0,1,0,0,0,0,0,0,0,0,
            0,0,0,15,0,0,0,0,40,0,
            0,0,0,0,0,0,0,0,0,0,
            0,0,0,0,39,0,0,40,0,39,
            0,39,39,0,0,40,48,0,0,0,
            0,0,0,0,50,0,0,0,0,0
        };
    };
    public final static byte termCheck[] = TermCheck.termCheck;
    public final int termCheck(int index) { return termCheck[index]; }

    public interface TermAction {
        public final static char termAction[] = {0,
            304,426,384,386,387,388,389,390,391,392,
            393,394,399,411,419,424,427,398,400,401,
            402,403,404,405,406,407,408,409,410,412,
            413,414,415,416,417,418,420,421,422,428,
            385,2,142,395,396,397,304,423,425,430,
            429,431,79,335,304,426,384,386,387,388,
            389,390,391,392,393,394,399,411,419,424,
            427,398,400,401,402,403,404,405,406,407,
            408,409,410,412,413,414,415,416,417,418,
            420,421,422,428,385,180,142,395,396,397,
            132,423,425,430,429,431,380,131,426,384,
            386,387,388,389,390,391,392,393,394,399,
            411,419,424,427,398,400,401,402,403,404,
            405,406,407,408,409,410,412,413,414,415,
            416,417,418,420,421,422,428,385,66,438,
            395,396,397,304,423,425,430,429,431,439,
            36,272,272,272,272,272,272,272,272,272,
            272,272,272,272,272,272,272,272,272,272,
            272,272,272,272,272,272,272,272,272,272,
            272,272,272,272,272,272,272,272,272,272,
            272,272,304,377,432,304,272,33,272,272,
            272,272,272,272,272,272,272,272,272,272,
            272,272,272,272,272,272,272,272,272,272,
            272,272,272,272,272,272,272,272,272,272,
            272,272,272,272,272,272,272,272,272,40,
            694,432,304,272,40,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,303,304,377,39,741,432,304,
            377,39,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            304,142,377,37,788,432,304,377,37,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,264,304,377,
            43,835,432,265,377,43,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,377,304,304,377,433,8,304,
            433,377,184,181,262,258,256,260,348,349,
            350,345,346,212,334,141,311,253,314,315,
            220,218,207,319,252,251,322,183,324,325,
            168,247,328,245,244,331,332,333,63,926,
            432,266,304,280,304,140,63,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            377,377,377,64,377,377,377,377,377,377,
            377,377,377,377,377,377,377,377,377,377,
            142,241,282,279,317,304,272,377,377,377,
            377,377,304,53,377,432,304,304,304,64,
            943,432,304,304,377,377,377,377,377,130,
            233,377,184,181,262,258,256,260,348,349,
            350,345,346,212,246,274,304,233,304,184,
            181,262,258,256,260,348,349,350,345,346,
            212,142,241,282,279,36,600,52,62,432,
            33,647,304,47,304,304,304,304,304,304,
            304,304,304,369,304,304,304,304,316,304,
            304,304,304,304,304,304,304,304,304,304,
            304,304,304,304,246,304,304,276,304,246,
            304,246,246,304,304,374,174,304,304,304,
            304,304,304,304,376
        };
    };
    public final static char termAction[] = TermAction.termAction;
    public final int termAction(int index) { return termAction[index]; }

    public interface Asb {
        public final static char asb[] = {0,
            132,119,132,208,1,50,50,125,52,52,
            125,125,52,121,121,50,125,125,125,78,
            77,48,77,49,105,123,1,171,50,50,
            50,131,49,49,49,220,80,127,49,80,
            170,54,171,129,129,129,222,128,129,170,
            59,54,54,78,121,49,54
        };
    };
    public final static char asb[] = Asb.asb;
    public final int asb(int index) { return asb[index]; }

    public interface Asr {
        public final static byte asr[] = {0,
            40,3,4,5,6,7,8,9,10,11,
            43,44,45,17,12,18,19,20,21,22,
            23,24,25,26,27,28,13,29,30,31,
            32,33,53,34,35,14,36,37,38,47,
            15,48,49,16,42,50,51,39,1,2,
            0,47,0,2,43,44,45,42,3,4,
            5,6,7,8,9,10,11,12,13,14,
            1,16,41,48,15,0,1,39,0,17,
            18,19,20,21,22,23,24,25,46,26,
            27,28,29,30,31,32,33,34,35,36,
            37,38,15,39,4,5,8,6,7,12,
            13,9,10,11,14,3,1,16,41,0,
            40,0,49,0,42,0,40,39,41,1,
            2,3,4,5,6,7,8,9,10,11,
            17,12,18,19,20,21,22,23,24,25,
            46,26,27,28,13,29,30,31,32,33,
            34,35,14,36,37,38,15,16,0,41,
            2,40,43,44,45,17,18,19,20,21,
            22,23,24,25,26,27,28,29,30,31,
            32,33,34,35,36,37,38,47,15,48,
            49,16,42,52,39,50,51,14,3,9,
            10,11,4,5,8,6,7,12,13,1,
            0,50,0
        };
    };
    public final static byte asr[] = Asr.asr;
    public final int asr(int index) { return asr[index]; }

    public interface Nasb {
        public final static byte nasb[] = {0,
            11,18,1,8,6,33,33,35,18,18,
            35,35,18,18,18,33,35,35,35,37,
            24,29,24,20,14,18,26,6,33,33,
            33,33,4,4,4,18,31,39,4,31,
            41,22,26,20,20,20,18,39,20,27,
            18,19,22,37,18,20,19
        };
    };
    public final static byte nasb[] = Nasb.nasb;
    public final int nasb(int index) { return nasb[index]; }

    public interface Nasr {
        public final static byte nasr[] = {0,
            11,22,0,6,0,13,0,11,20,0,
            19,18,0,11,21,15,8,0,17,2,
            0,16,0,14,0,3,12,0,25,0,
            7,0,4,0,3,0,5,0,1,0,
            27,0
        };
    };
    public final static byte nasr[] = Nasr.nasr;
    public final int nasr(int index) { return nasr[index]; }

    public interface TerminalIndex {
        public final static byte terminalIndex[] = {0,
            45,1,3,4,5,6,7,8,9,10,
            11,16,29,38,43,47,15,17,18,19,
            20,21,22,23,24,26,27,28,30,31,
            32,33,34,36,37,39,40,41,50,2,
            54,48,12,13,14,25,42,44,46,51,
            53,49,35,55
        };
    };
    public final static byte terminalIndex[] = TerminalIndex.terminalIndex;
    public final int terminalIndex(int index) { return terminalIndex[index]; }

    public interface NonterminalIndex {
        public final static byte nonterminalIndex[] = {0,
            68,62,61,60,64,65,67,59,0,0,
            66,71,0,63,69,0,70,56,0,57,
            0,58,0,0,0,0,0,0
        };
    };
    public final static byte nonterminalIndex[] = NonterminalIndex.nonterminalIndex;
    public final int nonterminalIndex(int index) { return nonterminalIndex[index]; }

    public interface ScopePrefix {
        public final static byte scopePrefix[] = {
            1
        };
    };
    public final static byte scopePrefix[] = ScopePrefix.scopePrefix;
    public final int scopePrefix(int index) { return scopePrefix[index]; }

    public interface ScopeSuffix {
        public final static byte scopeSuffix[] = {
            4
        };
    };
    public final static byte scopeSuffix[] = ScopeSuffix.scopeSuffix;
    public final int scopeSuffix(int index) { return scopeSuffix[index]; }

    public interface ScopeLhs {
        public final static byte scopeLhs[] = {
            3
        };
    };
    public final static byte scopeLhs[] = ScopeLhs.scopeLhs;
    public final int scopeLhs(int index) { return scopeLhs[index]; }

    public interface ScopeLa {
        public final static byte scopeLa[] = {
            52
        };
    };
    public final static byte scopeLa[] = ScopeLa.scopeLa;
    public final int scopeLa(int index) { return scopeLa[index]; }

    public interface ScopeStateSet {
        public final static byte scopeStateSet[] = {
            1
        };
    };
    public final static byte scopeStateSet[] = ScopeStateSet.scopeStateSet;
    public final int scopeStateSet(int index) { return scopeStateSet[index]; }

    public interface ScopeRhs {
        public final static byte scopeRhs[] = {0,
            67,42,0,52,0
        };
    };
    public final static byte scopeRhs[] = ScopeRhs.scopeRhs;
    public final int scopeRhs(int index) { return scopeRhs[index]; }

    public interface ScopeState {
        public final static char scopeState[] = {0,
            176,170,222,182,260,258,256,252,251,247,
            0
        };
    };
    public final static char scopeState[] = ScopeState.scopeState;
    public final int scopeState(int index) { return scopeState[index]; }

    public interface InSymb {
        public final static byte inSymb[] = {0,
            0,72,73,16,46,35,34,32,31,28,
            26,25,23,22,21,18,7,6,8,5,
            4,65,3,14,74,1,67,42,47,47,
            47,58,57,57,59,39,68,1,79,68,
            16,49,67,60,60,60,1,40,60,81,
            80,70,48,45,44,43,70
        };
    };
    public final static byte inSymb[] = InSymb.inSymb;
    public final int inSymb(int index) { return inSymb[index]; }

    public interface Name {
        public final static String name[] = {
            "",
            "string",
            "integer",
            "%token",
            "%nterm",
            "%type",
            "%destructor",
            "%printer",
            "%union",
            "%left",
            "%right",
            "%nonassoc",
            "%prec",
            "%dprec",
            "%merge",
            "%debug",
            "%default-prec",
            "%define",
            "%defines",
            "%error-verbose",
            "%expect",
            "%expect-rr",
            "%file-prefix",
            "%glr-parser",
            "%initial-action",
            "%{",
            "%lex-param",
            "%locations",
            "%name-prefix",
            "%no-default-prec",
            "%no-lines",
            "%nondeterministic-parser",
            "%output",
            "%parse-param",
            "%pure-parser",
            "%}",
            "%require",
            "%skeleton",
            "%start",
            "%token-table",
            "%verbose",
            "%yacc",
            "=",
            ";",
            "|",
            "identifier",
            ":",
            "%%",
            "{",
            "}",
            "<",
            ">",
            "$empty",
            "OTHER_C_CHAR",
            "EOF_TOKEN",
            "ERROR_TOKEN",
            "input",
            "grammar",
            "declaration",
            "grammar_declaration",
            "string_content",
            "bracedCode",
            "symbol",
            "symbol_defs_1",
            "type",
            "symbols_1",
            "precedence_declarator",
            "symbol_def",
            "string_as_id",
            "rules",
            "action",
            "nonBraceToken"
        };
    };
    public final static String name[] = Name.name;
    public final String name(int index) { return name[index]; }

    public final int originalState(int state) {
        return -baseCheck[state];
    }
    public final int asi(int state) {
        return asb[originalState(state)];
    }
    public final int nasi(int state) {
        return nasb[originalState(state)];
    }
    public final int inSymbol(int state) {
        return inSymb[originalState(state)];
    }

    /**
     * assert(! goto_default);
     */
    public final int ntAction(int state, int sym) {
        return baseAction[state + sym];
    }

    /**
     * assert(! shift_default);
     */
    public final int tAction(int state, int sym) {
        int i = baseAction[state],
            k = i + sym;
        return termAction[termCheck[k] == sym ? k : i];
    }
    public final int lookAhead(int la_state, int sym) {
        int k = la_state + sym;
        return termAction[termCheck[k] == sym ? k : la_state];
    }
}
