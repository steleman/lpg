package bisonToLpg.ast;

import java.util.ArrayList;
import java.util.List;

public class Alternative implements ASTNode {
   
   public List<Symbol> rhsSymbols;

   public Alternative() {
      rhsSymbols = new ArrayList<Symbol>();
   }
   
   public String toString() {
      if ( rhsSymbols.isEmpty() ) {
         return "%empty";
      } else {
         StringBuilder result = new StringBuilder();
         boolean spaceNeeded = false;
         for (Symbol s: rhsSymbols) {
            if ( spaceNeeded ) {
               result.append(' ');
            } else {
               spaceNeeded = true;
            }
            result.append(s);
         }
         return result.toString();
      }
   }
   
}
