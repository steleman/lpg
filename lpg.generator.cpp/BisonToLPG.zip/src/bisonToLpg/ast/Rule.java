package bisonToLpg.ast;

public class Rule implements ASTNode {
   
   public Symbol left;
   public Rhs right;
   
   public Rule(Symbol left, Rhs right) {
      this.left = left;
      this.right = right;
   }

   public String toString() {
      StringBuilder result = new StringBuilder();
      result.append(left);
      result.append(" ::= ");
      result.append(right);
      return result.toString();
   }

}
