package bisonToLpg.ast;

public class Symbol implements ASTNode {
   
   public String name;

   public Symbol(String name) {
      this.name = name;
   }

   public String toString() {
      return name;
   }
}
