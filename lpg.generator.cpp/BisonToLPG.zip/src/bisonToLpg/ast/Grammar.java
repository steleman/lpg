package bisonToLpg.ast;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Grammar implements ASTNode {
   
   public Map<String,String> declarationInfo;
   public List<Rule> rules;
   
   public Grammar() {
      rules = new ArrayList<Rule>();
   }
   
   public Grammar(Rule firstElement) {
      rules = new ArrayList<Rule>();
      rules.add(firstElement);
   }
   
   public String toString() {
      StringBuilder result = new StringBuilder();
      for (Rule r: rules) {
         result.append(r);
         result.append("; ");
      }
      return result.toString();
   }

}
