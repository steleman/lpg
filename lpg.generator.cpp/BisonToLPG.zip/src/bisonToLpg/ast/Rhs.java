package bisonToLpg.ast;

import java.util.ArrayList;
import java.util.List;

public class Rhs implements ASTNode {
   
   public List<Alternative> alternatives;

   public Rhs(Alternative firstElement) {
      alternatives = new ArrayList<Alternative>();
      alternatives.add(firstElement);
   }
   
   public String toString() {
      StringBuilder result = new StringBuilder();
      boolean vBarNeeded = false;
      for (Alternative alt: alternatives) {
         if ( vBarNeeded ) {
            result.append(" | ");
         } else {
            vBarNeeded = true;
         }
         result.append(alt);
      }
      return result.toString();
   }

}
