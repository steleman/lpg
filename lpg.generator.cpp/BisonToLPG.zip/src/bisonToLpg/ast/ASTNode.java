package bisonToLpg.ast;

public interface ASTNode {

}
