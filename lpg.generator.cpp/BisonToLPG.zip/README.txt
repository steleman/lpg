This program creates an LPG input file from a Bison input file. It is invoked
as follows:

   java bisonToLpg.LPGRuleGenerator prolog-file-name bison-file-name epilog-file-name lpg-file-name

An LPG input file is written to the file named by lpg-file-name, consisting of
the following:

   * the contents of the file named by prolog-file-name (typically LPG
     %options directives and LPG %Globals and %Define sections)
     
   * LPG %Terminals, %Start, and %Rules sections, generated from the Bison
     declarations and grammar in the file named by bison-file-name, but with any
     actions in the Bison file stripped out

   * the contents of the file named by epilog-file-name (typically an LPG
     %Headers section)

LPG requires that any string-constant nonterminals used in the grammar be
declared in the %Terminals section aliased with some identifier; such an
identifier is optional in Bison. Whenever a string-constant nonterminal is
aliased with an identifier in a Bison %token declaration, we use that identifier
in the LPG %Terminals section. When the Bison file does not specify an
identifier for a string-constant nonterminal, we synthesize one from the string
constant. This synthesis is not guaranteed to produce identifiers unique from
all other nonterminal identifiers, but the identifiers produced tend in practice
to be similar to those we have encountered for manually aliased string-constant
nonterminals. The synthesis is based on names for individual special characters
that are specified in a file SpecialCharacterNames.properties that the program
expects to find in the directory from which it is invoked. The file consists of
a series of lines of the form

   name=character
   
as in the following examples:

   LPAR=(
   RPAR=)
   EQ==
   UNDER=_
   SPACE=

A default file is supplied with the program, but it can be customized. If the
file is not present, the synthesis algorithm uses a name of the form CHARn
for the character with ASCII code n (for example, CHAR35 for '#').  